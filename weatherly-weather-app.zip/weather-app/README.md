# Weatherly

Modern SPA weather dashboard built with HTML, CSS and vanilla JavaScript.

## Features
- Current weather
- 7-day forecast
- 24-hour forecast
- Rain probability and precipitation
- Wind speed, gusts and direction
- Humidity, pressure, visibility and UV index
- Sunrise / sunset
- City search
- Browser geolocation
- Celsius / Fahrenheit
- Dark / light mode
- Temperature and rain charts
- Interactive OpenStreetMap map
- Responsive mobile + desktop UI
- Local storage for last location and theme

## Run
Open `index.html` in a modern browser. For geolocation and some browser security policies, serving the folder through a local/static web server is recommended.

## Data
Weather and geocoding are provided by Open-Meteo.
Map tiles are provided by OpenStreetMap through Leaflet.
Charts use Chart.js.
