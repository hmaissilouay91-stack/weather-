document.getElementById("locationBtn").addEventListener("click",()=>{
  if(!navigator.geolocation){showError("Geolocation is not supported by this browser.");return}
  showLoading(true);
  navigator.geolocation.getCurrentPosition(async pos=>{
    try{
      await loadLocation({lat:pos.coords.latitude,lon:pos.coords.longitude,name:"My location",country:""});
    }catch(e){showError(e.message)}
    finally{showLoading(false)}
  },err=>{
    showLoading(false);
    showError("Location permission was denied or unavailable.");
  },{enableHighAccuracy:true,timeout:10000});
});
