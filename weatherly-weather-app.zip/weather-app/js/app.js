const state={lat:36.8065,lon:10.1815,name:"Tunis",country:"Tunisia",unit:"celsius",wind:"kmh",weather:null};
const $=id=>document.getElementById(id);
function showLoading(on){$("loading").classList.toggle("hidden",!on)}
function showError(msg){const el=$("status");el.textContent=msg;el.hidden=false;setTimeout(()=>el.hidden=true,5000)}
function saveState(){localStorage.setItem("weather-location",JSON.stringify({lat:state.lat,lon:state.lon,name:state.name,country:state.country}))}
function loadSaved(){
  try{const x=JSON.parse(localStorage.getItem("weather-location"));if(x)return x}catch{}
  return null;
}
async function loadLocation(place){
  state.lat=place.lat;state.lon=place.lon;state.name=place.name;state.country=place.country||"";
  saveState(); showLoading(true);
  try{
    state.weather=await fetchWeather(state.lat,state.lon,state.unit,state.wind);
    renderWeather();
    updateMap(state.lat,state.lon,state.name);
  }catch(e){showError(e.message)}
  finally{showLoading(false)}
}
function renderWeather(){
  const w=state.weather,c=w.current,d=w.daily,h=w.hourly;
  const [desc,icon]=weatherInfo(c.weather_code);
  $("locationName").textContent=[state.name,state.country].filter(Boolean).join(", ");
  $("localTime").textContent=new Date(c.time).toLocaleString([], {weekday:"long",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
  $("dayNight").textContent=c.is_day?"DAY":"NIGHT";
  $("currentTemp").textContent=Math.round(c.temperature_2m);
  $("tempUnit").textContent=state.unit==="celsius"?"°C":"°F";
  $("weatherDescription").textContent=desc;
  $("weatherIcon").textContent=icon;
  $("feelsLike").textContent=`Feels like ${Math.round(c.apparent_temperature)}°`;
  $("highTemp").textContent=`${Math.round(d.temperature_2m_max[0])}°`;
  $("lowTemp").textContent=`${Math.round(d.temperature_2m_min[0])}°`;
  $("humidity").textContent=`${Math.round(c.relative_humidity_2m)}%`;
  $("wind").textContent=`${Math.round(c.wind_speed_10m)} ${state.wind==="kmh"?"km/h":"mph"}`;
  $("rain").textContent=`${Number(c.precipitation||0).toFixed(1)} mm`;
  $("pressure").textContent=`${Math.round(c.pressure_msl)} hPa`;
  $("visibility").textContent=`${(c.visibility/1000).toFixed(1)} km`;
  $("uv").textContent=Number(c.uv_index).toFixed(1);
  $("sunrise").textContent=formatTime(d.sunrise[0]);
  $("sunset").textContent=formatTime(d.sunset[0]);
  $("windDirection").textContent=`${cardinal(c.wind_direction_10m)} (${Math.round(c.wind_direction_10m)}°)`;
  $("gusts").textContent=`${Math.round(c.wind_gusts_10m)} ${state.wind==="kmh"?"km/h":"mph"}`;
  $("coordinates").textContent=`${state.lat.toFixed(3)}, ${state.lon.toFixed(3)}`;
  $("windCompass").querySelector(".needle").style.transform=`rotate(${c.wind_direction_10m}deg)`;
  renderHourly(h);
  renderDaily(d);
  makeCharts(state.weather);
}
function renderHourly(h){
  $("hourlyForecast").innerHTML=h.time.slice(0,24).map((t,i)=>{
    const [desc,icon]=weatherInfo(h.weather_code[i]);
    return `<div class="hour ${i===0?"active":""}">
      <time>${i===0?"Now":new Date(t).toLocaleTimeString([], {hour:"numeric"})}</time>
      <div class="icon" title="${desc}">${icon}</div>
      <div class="t">${Math.round(h.temperature_2m[i])}°</div>
      <span class="rain-prob">☔ ${h.precipitation_probability[i]||0}%</span>
    </div>`
  }).join("");
}
function renderDaily(d){
  $("dailyForecast").innerHTML=d.time.map((t,i)=>{
    const [desc,icon]=weatherInfo(d.weather_code[i]);
    return `<div class="day-row">
      <div class="day-name">${formatDay(t,i)}<small class="muted" style="display:block">${desc}</small></div>
      <div class="day-icon">${icon}</div>
      <div class="day-rain">☔ ${d.precipitation_probability_max[i]||0}%</div>
      <div class="day-temp">${Math.round(d.temperature_2m_max[i])}° / ${Math.round(d.temperature_2m_min[i])}°</div>
    </div>`
  }).join("");
}
$("themeBtn").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("weather-theme",document.body.classList.contains("dark")?"dark":"light");
  if(state.weather)makeCharts(state.weather);
});
$("unitBtn").addEventListener("click",async()=>{
  state.unit=state.unit==="celsius"?"fahrenheit":"celsius";
  $("unitBtn").textContent=state.unit==="celsius"?"°C":"°F";
  await loadLocation({lat:state.lat,lon:state.lon,name:state.name,country:state.country});
});
if(localStorage.getItem("weather-theme")==="dark")document.body.classList.add("dark");
const saved=loadSaved();
loadLocation(saved||{lat:state.lat,lon:state.lon,name:state.name,country:state.country});
